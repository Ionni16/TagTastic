package com.moko.support.nordic.entity;

public class LightSensorStoreData {
    public String time;
    public String status;
}
