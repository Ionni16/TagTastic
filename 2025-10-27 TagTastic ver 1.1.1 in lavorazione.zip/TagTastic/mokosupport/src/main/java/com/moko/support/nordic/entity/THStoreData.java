package com.moko.support.nordic.entity;

public class THStoreData {
    public String time;
    public String temp;
    public String humidity;
}
