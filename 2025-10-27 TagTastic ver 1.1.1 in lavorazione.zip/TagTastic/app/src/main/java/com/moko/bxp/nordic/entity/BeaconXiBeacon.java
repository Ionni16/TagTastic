package com.moko.bxp.nordic.entity;

import java.io.Serializable;


public class BeaconXiBeacon implements Serializable {
    public String rangingData;
    public String uuid;
    public String major;
    public String minor;
    public String distanceDesc;
    public String txPower;
}
