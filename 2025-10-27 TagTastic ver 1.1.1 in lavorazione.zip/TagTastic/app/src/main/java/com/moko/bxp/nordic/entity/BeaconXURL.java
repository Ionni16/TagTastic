package com.moko.bxp.nordic.entity;

import java.io.Serializable;


public class BeaconXURL implements Serializable {
    public String rangingData;
    public String url;
}
