package com.moko.bxp.nordic.entity;

import java.io.Serializable;


public class BeaconXAxis implements Serializable {
    public String dataRate;
    public String scale;
    public String txPower;
    public String rangingData;
    public String sensitivity;
    public String x_data;
    public String y_data;
    public String z_data;
}
