package com.moko.bxp.nordic.able;

public interface ISlotDataAction {
    boolean isValid();

    void sendData();

    void resetParams();
}
