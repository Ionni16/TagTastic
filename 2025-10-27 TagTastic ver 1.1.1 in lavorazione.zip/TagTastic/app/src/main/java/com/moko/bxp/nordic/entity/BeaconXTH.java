package com.moko.bxp.nordic.entity;

import java.io.Serializable;


public class BeaconXTH implements Serializable {
    public String temperature;
    public String humidity;
    public String txPower;
    public String rangingData;
}
